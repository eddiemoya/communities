<?php
	class UserActions extends UserActionQuery {
		private $_active;
		private $_apiKey;
		private $_url;
		private $_siteSection;
		
		public function __construct() {

		}
    }