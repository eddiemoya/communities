<?php
	/*
	Plugin Name: UserActions
	Plugin URL: http://wordpress.org/
	Description: Tracking of all User Actions
	Author: Sebastian Frohm
	Version: 0.1
	*/

	//include base definitions
	//include('globals/USERACTIONS.constants.php');
	@define('ACTIONJACSON_BASE_DIR', 'action_jackson/');

	@define('ACTIONJACSON_ACTIONS_DIR', 'base/');
	@define('ACTIONJACSON_INSTANCES_DIR', 'controllers/instances/');
	@define('ACTIONJACSON_VIEWS_DIR', 'views/');
	
	//include(USERACTIONS_ACTIONS_DIR.'UserActionsViews.actions.php');
	//include(USERACTIONS_ACTIONS_DIR.'UserActionsAdmin.actions.php');
	include('base/action_jackson_query.php');

    function get_actions() {
        global $current_user;
        get_currentuserinfo();

        $ajQuery = new ActionJacksonQuery();

        $ajQuery->getUserActions('posts', 'ID', $current_user->ID);
        //$ajQuery->getUserActions('term', 'term_id', $current_user->ID, null, null, null, 'category');
        //$ajQuery->addUserAction(4, 'term', 'upvote', 'something', 1);
    }

//    add_action('init', 'get_actions');

    add_filter( 'pre_get_posts', array('ActionJacksonQuery', 'getUserActions'), 2, 3);