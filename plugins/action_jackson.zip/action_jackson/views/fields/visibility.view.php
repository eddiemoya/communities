<tr>
	<td>Turn the header/footer on/off</td>
	<td>
		<select name="fitStudioOptions-visibility">
			<option <?php echo ($value == 'on') ? 'selected' : '';?> value="on">On</option>
			<option <?php echo ($value == 'off') ? 'selected' : '';?> value="off">Off</option>
		</select>
	</td>
</tr>