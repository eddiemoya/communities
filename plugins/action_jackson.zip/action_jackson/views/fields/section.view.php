<tr>
	<td>Additional Site Section <br />(This value will be something like "blog" or "gear", which allows you to pull a header from a particular section of the fitstudio website.  You can leave it blank to get a header with no tab selected)</td>
	<td>
		<input type="text" value="<?php echo $value; ?>" name="fitStudioOptions-siteSection" />
	</td>
</tr>