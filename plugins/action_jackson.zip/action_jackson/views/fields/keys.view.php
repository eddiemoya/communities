<tr>
	<td>API Key</td>
	<td>
		<input type="text" value="<?php echo $value; ?>" name="fitStudioOptions-apiKey" id="fitStudioOptions-apiKey" />
	</td>
</tr>