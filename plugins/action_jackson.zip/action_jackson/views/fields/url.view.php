<tr>
	<td>API Url (Please ensure this is in the http://www.mysite.com/ template)</td>
	<td>
		<input type="text" value="<?php echo $value; ?>" name="fitStudioOptions-apiUrl" />
	</td>
</tr>