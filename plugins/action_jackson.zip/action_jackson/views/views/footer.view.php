<p>&nbsp;</p>
              <!-- BEGIN FOOTER INCLUDE inc_footer -->
<div id="fitstudio_footer" class="clearfix container_12">
  <div class="grid_3 alpha">

    <a href="http://www.fitstudio.com/" class="logo">
      <img alt="FitStudio by Sears" src="http://www.fitstudio.com/images/fs2/fs_bot_logo.png?1316610704">
</a>  </div>
  <div class="grid_2 about">
    <ul class="footer_nav">
      <li><a href="http://www.fitstudio.com/welcome/about_fitstudio" rel="About FitStudio">About FitStudio</a></li>
      <li><a href="#" id="contact_us" rel="http://www.fitstudio.com/contacts/new">Contact Us</a></li>
    </ul>
  </div>
  <div class="grid_2 policy">
    <ul class="footer_nav">

      <li><a href="http://www.fitstudio.com/welcome/privacy_policy" rel="Privacy Policy">Privacy Policy</a></li>
      <li><a href="http://www.fitstudio.com/welcome/california_privacy_policy" rel="California Privacy Policy">California Privacy Policy</a></li>

    </ul>
  </div>
  <div class="grid_3 terms">
    <ul class="footer_nav">

      <li><a href="http://www.fitstudio.com/welcome/terms_and_conditions" rel="Terms of Use">Terms of Use</a></li>
      <li><div class="copyright">© <?php echo date('Y', strtotime('now')); ?> Sears Brands LLC</div></li>

    </ul>
  </div>
  <div class="grid_2 community">
    <ul>
      <li>
        <a href="http://www.youtube.com/user/fitstudio" onclick="window.open(this.href);return false;" rel="youtube" data-omniture="Footerxyoutube" class="rss">&nbsp;</a>
      </li>
      <li>
        <a href="http://fitstudiofacebook.com" onclick="window.open(this.href);return false;" rel="facebook" data-omniture="Footerxfacebook" class="facebook">&nbsp;</a>
      </li>
      <li>
        <a href="http://fitstudiotwitter.com" onclick="window.open(this.href);return false;" rel="twitter" data-omniture="Footerxtwitter" class="twitter">&nbsp;</a>
      </li>
    </ul>
    <!--<img alt="FitStudio Communities" src="http://fitstudio.com/images/fs2/footer_community_icons.png?1316610704" />-->
  </div>
</div>

<!-- END FOOTER INCLUDE inc_footer -->
