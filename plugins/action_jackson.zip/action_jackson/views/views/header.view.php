<link href="http://www.fitstudio.com/assets/fitstudio_branding.css?1324401446" media="all" rel="stylesheet" type="text/css">
<!--[if IE 7 ]><link href="http://www.fitstudio.com/stylesheets/ie7.css?1324401390" media="screen" rel="stylesheet" type="text/css" /><![endif]-->
<!--[if IE 7 ]><div id="fitstudio_header" class="ie7 clearfix fitstudio_header container_12"> <![endif]-->
<!--[if IE 8 ]><div id="fitstudio_header" class="ie8 clearfix fitstudio_header container_12"> <![endif]-->
<!--[if (gte IE 9)|!(IE)]><!--> <div id="fitstudio_header" class="clearfix fitstudio_header container_12"> <!--<![endif]-->
  <div id="head_logo_action_bar">
  <div id="fs_logo">
    <a href="http://www.fitstudio.com/">
      <img alt="FitStudio" src="http://www.fitstudio.com/images/fs2/fs_top_logo.png?1324401332">
</a>  </div>

  <div id="header" class="grid_8 push_4">
    <div id="header_action_bar" class="info_box header_profile_box" data-target-uri="/profile_box" data-user-specific-page="">
    </div>
  </div>
<div class="cart-container"><a href="http://uxdev:3001/cart/?_=13250185851660.5539387201424688"><img src="http://uxdev:3001/wp-content/themes/gear/images/cart.jpg" class="cart-image" alt="Go to Cart"><img src="http://uxdev:3001/wp-content/themes/gear/images/backgrounds/cart-line.png" class="cart-line" alt="Go to Cart"></a></div></div>

  <div id="header_navigation" class="clearfix">
  <ul class="top_navigation clearfix"><li id="home"><a href="http://www.fitstudio.com/">Home</a></li><li id="workouts"><a href="http://www.fitstudio.com/getting_fit">Getting Fit<div id="getting_fit_menu" class="hide top_drop_menu">
      <div class="top_border"></div>
      <div class="top_nav_block">
        <ul class="wp_menu">
            <li>
              <a href="http://www.fitstudio.com/exercises" data-omniture="GettingFitxTopNavxExercises" id="exercises_submenu">Exercises</a>
            </li>
            <li>
              <a href="http://www.fitstudio.com/workouts" data-omniture="GettingFitxTopNavxWorkouts" id="workouts_submenu">Workouts</a>
            </li>
            <li>
              <a href="http://www.fitstudio.com/programs" data-omniture="GettingFitxTopNavxPrograms" id="programs_submenu">Programs</a>
            </li>
          <li>
            <a href="http://etrainer.fitstudio.com" id="etrainer">eTrainer</a>
          </li>
        </ul>
      </div>
    </div></a></li><li id="articles"><a href="http://www.fitstudio.com/articles">Living Healthy<div id="living_healthy_menu" class="hide top_drop_menu">
      <div class="top_border"></div>
      <div class="top_nav_block">
        <ul class="wp_menu">
            <li class="">
              <a href="http://www.fitstudio.com/articles/fitness-topics/diet-nutrition/list" data-omniture="ArticlesxTopNavxDiet &amp; Nutrition" id="diet_nutrition_submenu">Diet &amp; Nutrition</a>
            </li>
            <li class="">
              <a href="http://www.fitstudio.com/articles/fitness-topics/equipment/list" data-omniture="ArticlesxTopNavxEquipment" id="equipment_submenu">Equipment</a>
            </li>
            <li class="">
              <a href="http://www.fitstudio.com/articles/fitness-topics/fitness/list" data-omniture="ArticlesxTopNavxFitness" id="fitness_submenu">Fitness</a>
            </li>
            <li class="">
              <a href="http://www.fitstudio.com/articles/fitness-topics/health/list" data-omniture="ArticlesxTopNavxHealth" id="health_submenu">Health</a>
            </li>
            <li class="">
              <a href="http://www.fitstudio.com/articles/fitness-topics/motivation/list" data-omniture="ArticlesxTopNavxMotivation" id="motivation_submenu">Motivation</a>
            </li>
        </ul>
      </div>
    </div></a></li><li id="community"><a href="http://www.fitstudio.com/community">Community<div id="community_menu" class="hide top_drop_menu">
      <div class="top_border"></div>
      <ul class="wp_menu">
        <li>
          <a href="http://blog.fitstudio.com" id="blog_submenu">Blog</a>
        </li>
        <li>
          <a href="http://www.fitstudio.com/forums" id="forums_submenu">Forums</a>
        </li>
        <li>
          <a href="http://www.fitstudio.com/experts" id="expert_submenu">Experts</a>
        </li>
      </ul>
    </div></a></li><li id="gear"><a href="<?php echo site_url(); ?>">Gear<div id="gear_menu" class="hide top_drop_menu">
      <div class="top_border"></div>
      <ul class="wp_menu">
        <li>
          <a href="<?php echo site_url('/category/treadmill'); ?>">Treadmills</a>
        </li>
        <li>
          <a href="<?php echo site_url('/category/ellipticals'); ?>">Ellipticals</a>
        </li>
        <li>
          <a href="<?php echo site_url('/category/exercise-cycles'); ?>">Exercise Cycles</a>
        </li>
        <li>
          <a href="<?php echo site_url('/category/strength-weight-training'); ?>">Strength &amp; Weight Training</a>
        </li>
        <li>
          <a href="<?php echo site_url('/category/fitness-accessories'); ?>">Fitness Accessories</a>
        </li>
        <li>
          <a href="<?php echo site_url('/category/incline-trainers'); ?>">Incline Trainers</a>
        </li>
        <li>
          <a href="<?php echo site_url('/category/rowers-steppers'); ?>">Rowers &amp; Steppers</a>
        </li>
        <li>
          <a href="<?php echo site_url('/category/inversion'); ?>">Inversion</a>
        </li>
        <li>
          <a href="<?php echo site_url('/category/boxing-mixed-martial-arts'); ?>">Boxing &amp; Mixed Martial Arts</a>
        </li>
        <li>
          <a href="<?php echo site_url('/category/yoga-pilates'); ?>">Yoga &amp; Pilates</a>
        </li>
        <li>
          <a href="<?php echo site_url('/category/brands'); ?>">Brands</a>
        </li>
      </ul>
    </div></a></li></ul>
  <div class="fitstudio_top_round_corners clear ">
    <div class="right_corner"></div>
  </div>
  <div id="navigation_indicator"></div>
</div>

  <a href="http://www.fitstudio.com/branding/profile_box" id="fitstudio_profile_box_url" style="display:none">Fitstudio Profile Box</a>
  <a href="#" id="fitstudio_login" rel="https://www.fitstudio.com/login" style="display:none">Login</a>
  <a href="#" id="fitstudio_register" rel="https://www.fitstudio.com/users/new" style="display:none">Register</a>
</div>

<script src="http://www.fitstudio.com/assets/fitstudio_branding.js?1324401436" type="text/javascript"></script>
<script type="text/javascript">
//<![CDATA[
  var Config = typeof(Config) == "undefined" ? {} : Config;
  Config.railsEnv = "production";
  Config.host = "www.fitstudio.com";

//]]>
</script>

<link rel="stylesheet" id="fonts-css" href="http://uxdev:3001/wp-content/themes/gear/css/fonts.css?ver=3.1.3" type="text/css" media="all">